<?php 
namespace App\core;
class Database{

    function __construct() {
    }
   
}
