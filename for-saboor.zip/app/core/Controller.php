<?php

namespace App\core;

class Controller
{
  
   
}
