<!DOCTYPE html>
<html>

<head>
    <title>Home</title>
</head>

<body>
    <h1>This is the home page</h1>
</body>

</html>
<h1>views/home</h1>

